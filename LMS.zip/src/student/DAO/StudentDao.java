package student.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import jdbc.jdbcUtil;
import student.DTO.ReinstatementDataBean;
import student.DTO.ScholarshipDataBean;
import student.DTO.StudentDataBean;

public class StudentDao {
	private static StudentDao instance = new StudentDao();
	public static StudentDao getInstance() {
		return instance;
	}
	private StudentDao(){
	}
	public List<ScholarshipDataBean> selectScholarship_All(Connection conn,int id)throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try{
			pstmt = conn.prepareStatement("select * from SCHOLARSHIP where SD_NUM = ? order by SYS_DATE");
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			if(!rs.next()){
				return Collections.emptyList();
			}
			List<ScholarshipDataBean> itemList = new ArrayList<ScholarshipDataBean>();
			do{
				ScholarshipDataBean item = makeItemScholarshipResultSet(rs);
				itemList.add(item);
			}while(rs.next());
			return itemList;
		}finally{
			jdbcUtil.close(rs);
			jdbcUtil.close(pstmt);
		}
	}
	public List<ScholarshipDataBean> selectScholarship(Connection conn,int id,String year,int grade,String semester)throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try{
			pstmt = conn.prepareStatement("select * from SCHOLARSHIP where SD_NUM = ? and year = ? and GRADE = ? and SEMESTER = ?");
			pstmt.setInt(1, id);
			pstmt.setString(2, year);
			pstmt.setInt(3, grade);
			pstmt.setString(4, semester);
			rs = pstmt.executeQuery();
			if(!rs.next()){
				return Collections.emptyList();
			}
			List<ScholarshipDataBean> itemList = new ArrayList<ScholarshipDataBean>();
			do{
				ScholarshipDataBean article = makeItemScholarshipResultSet(rs);
				itemList.add(article);
			}while(rs.next());
			return itemList;
		}finally{
			jdbcUtil.close(rs);
			jdbcUtil.close(pstmt);
		}
	}
	public StudentDataBean selectStudent(Connection conn,int id)throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StudentDataBean item = null;
		try{
			pstmt = conn.prepareStatement("select * from student where sd_num = ?");
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			if(!rs.next()){
				return item;
			}else{
				item = makeItemStudentResultSet(rs);
			}
			return item;
		}finally{
			jdbcUtil.close(rs);
			jdbcUtil.close(pstmt);
		}
	}
	private ScholarshipDataBean makeItemScholarshipResultSet(ResultSet rs) throws SQLException{
		ScholarshipDataBean item = new ScholarshipDataBean();
		item.setNo(rs.getInt("NO"));
		item.setSd_num(rs.getInt("SD_NUM"));
		item.setYear(rs.getString("YEAR"));
		item.setGrade(rs.getInt("GRADE"));
		item.setSemester(rs.getString("SEMESTER"));
		item.setName(rs.getString("NAME"));
		item.setSum(rs.getInt("SUM"));
		item.setSys_date(rs.getTimestamp("SYS_DATE"));
		return item;
	}
	private ReinstatementDataBean makeItemReinstatementResultSet(ResultSet rs) throws SQLException{
		ReinstatementDataBean item = new ReinstatementDataBean();
		item.setSd_num(rs.getInt("sd_num"));
		item.setRe_loa_date(rs.getTimestamp("RE_LOA_DATE"));
		item.setLoa_end_year(rs.getString("LOA_END_YEAR"));
		item.setLoa_end_semester(rs.getString("LOA_END_SEMESTER"));
		item.setLoa_a_date(rs.getTimestamp("LOA_A_DATE"));
		item.setRe_start_date(rs.getTimestamp("RE_START_DATE"));
		item.setRe_end_date(rs.getTimestamp("RE_END_DATE"));
		return item;
	}
	private StudentDataBean makeItemStudentResultSet(ResultSet rs) throws SQLException{
		StudentDataBean item = new StudentDataBean();
/*		no;
		sd_num;// 학번
		sd_name; // 학생이름
		sd_passwd;// 학생 pw
		d_num;// 학과번호
		d_sub_num;// 부/복수전공번호
		sd_jumin;//학생 생일월일
		sd_hpone;//학생 핸드폰 번호
		sd_address;//학생 주소
		sd_email;//학생 이메일
		sd_ac_no;//계좌번호
		sd_ac_name;//계좌은행이름
		sd_grade;//현재학년
		sd_semester;//이수학기
		sd_start_date;//입학날짜
		sd_end_date;//졸업날짜
		sd_re_loa;//재학인지 휴학인지 상태값
		sd_specialty;//전공,부전공,복수전공인지 상태값
*/		item.setNo(rs.getInt("NO"));
		item.setSd_num(rs.getInt("SD_NUM"));
		item.setSd_name(rs.getString("SD_NAME"));
		item.setSd_passwd(rs.getString("sd_passwd"));
		item.setD_num(rs.getString("d_num"));
		item.setD_sub_num(rs.getString("d_sub_num"));
		item.setSd_jumin(rs.getString("sd_jumin"));
		item.setSd_hpone(rs.getString("sd_hpone"));
		item.setSd_address(rs.getString("sd_address"));
		item.setSd_email(rs.getString("sd_email"));
		item.setSd_ac_no(rs.getString("sd_ac_no"));
		item.setSd_ac_name(rs.getString("sd_ac_name"));
		item.setSd_grade(Integer.parseInt(rs.getString("sd_grade")));
		item.setSd_semester(Integer.parseInt(rs.getString("sd_semester")));
		item.setSd_start_date(rs.getTimestamp("sd_start_date"));
		item.setSd_end_date(rs.getTimestamp("sd_end_date"));
		item.setSd_re_loa(rs.getString("sd_re_loa"));
		item.setSd_specialty(rs.getString("sd_specialty"));

		return item;
	}
	
	/**************로그인 ***********/
	
	public int studentCheck(Connection conn , String sd_num, String sd_passwd) throws SQLException{

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String dbpasswd="";
		int x = -1; // 경우의 수를 저장할 변수 x. 초기값은 -1
		
		try{
			pstmt = conn.prepareStatement("select sd_passwd from student where sd_num = ?"); // 입력한 전달받은 id와 일치하는 passwd를 꺼내온다.
			pstmt.setString(1, sd_num);
			rs = pstmt.executeQuery();
			
			if(rs.next()){ // 테이블에 다음 레코드값이 존재할 경우,
				dbpasswd = rs.getString("sd_passwd"); // rs객체의 getString()메소드로 해당하는 컬럼명("passwd")의 쿼리의 결과값을 String타입으로 dbpasswd변수에 저장한다. 
				
				if(dbpasswd.equals(sd_passwd)){ // db에 저장된 암호(dbpasswd)와 사용자가 입력한 암호(passwd)가 같다면,
					x = 1; // 인증 성공 // 레코드 1줄 변경됨 // 경우의 수 x=1 저장.
				}
				else{ 
					x = 0; 
				} // 비밀번호 틀림 // 레코드의 변동이 없다. 즉, 0 // 입력한 암호와 db에 저장된 암호가 달라서 레코드가 변하지 않음. 경우의 수 x=0 저장.
			}
			else{ // 테이블에 레코드값이 존재하지 않을 경우,
				x = -1; 
				} // 해당 아이디 없음 // 경우의 수 x=-1 저장.
			
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			if(rs!=null) try{rs.close();} catch(SQLException ex){}
			if(pstmt!=null) try{pstmt.close();} catch(SQLException ex){}
			if(conn!=null) try{conn.close();} catch(SQLException ex){}
		}
		return x; // x에 저장된 값 리턴.
	}
	

	//loginPro.jsp
		public int professorCheck(Connection conn, String pf_num, String pf_passwd) throws SQLException{
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String dbpasswd="";
			int x = -1; // 경우의 수를 저장할 변수 x. 초기값은 -1
			
			try{
				pstmt = conn.prepareStatement("select pf_passwd from professor where pf_num = ?"); // 입력한 전달받은 id와 일치하는 passwd를 꺼내온다.
				pstmt.setString(1, pf_num);
				rs = pstmt.executeQuery();
				
				if(rs.next()){ // 테이블에 다음 레코드값이 존재할 경우,
					dbpasswd = rs.getString("pf_passwd"); // rs객체의 getString()메소드로 해당하는 컬럼명("passwd")의 쿼리의 결과값을 String타입으로 dbpasswd변수에 저장한다. 
					if(dbpasswd.equals(pf_passwd)){ // db에 저장된 암호(dbpasswd)와 사용자가 입력한 암호(passwd)가 같다면,
						x = 1; // 인증 성공 // 레코드 1줄 변경됨 // 경우의 수 x=1 저장.
					}
					else{ 
						x = 0; 
					} // 비밀번호 틀림 // 레코드의 변동이 없다. 즉, 0 // 입력한 암호와 db에 저장된 암호가 달라서 레코드가 변하지 않음. 경우의 수 x=0 저장.
				}
				else{ // 테이블에 레코드값이 존재하지 않을 경우,
					x = -1; 
					} // 해당 아이디 없음 // 경우의 수 x=-1 저장.
				
			}catch(Exception ex){
				ex.printStackTrace();
			}finally{
				if(rs!=null) try{rs.close();} catch(SQLException ex){}
				if(pstmt!=null) try{pstmt.close();} catch(SQLException ex){}
				if(conn!=null) try{conn.close();} catch(SQLException ex){}
			}
			return x; // x에 저장된 값 리턴.
		}
		/*********로그인 끝*********/
		
		//select 재학,휴학 상태인 학생 데이터
		public StudentDataBean selectLOA(Connection conn,int id,String loa)throws SQLException{
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			StudentDataBean item =null;
			try{
				pstmt = conn.prepareStatement("select * from student where sd_num = ? and SD_RE_LOA = ?");
				pstmt.setInt(1, id);
				pstmt.setString(2, loa);
				rs = pstmt.executeQuery();
				if(!rs.next()){
					return item;
				}else{
					item = makeItemStudentResultSet(rs);
					return item;
				}
			}finally{
				jdbcUtil.close(rs);
				jdbcUtil.close(pstmt);
			}
		}
		// 휴학 신청 insert 문
		public int insertReinstatementLOA(Connection conn,int id,String LOA_END_YEAR,String LOA_END_SEMESTER){
			PreparedStatement pstmt = null;
			try{
				pstmt = conn.prepareStatement("insert into REINSTATEMENT (sd_num,LOA_END_YEAR,LOA_END_SEMESTER) values(?,?,?)");
				pstmt.setInt(1, id);
				pstmt.setString(2, LOA_END_YEAR);
				pstmt.setString(3, LOA_END_SEMESTER);
				int count = pstmt.executeUpdate();
				return count;

			}catch(SQLException e){
				throw new RuntimeException("DB 에러:"+e.getMessage(), e);
			}
			finally{
				jdbcUtil.close(pstmt);
			}
		}
		// 복학 신청 update 문
		public int updateReinstatementLOA(Connection conn,int id,String LOA_A_DATE){
			PreparedStatement pstmt = null;
			try{
				pstmt = conn.prepareStatement("update REINSTATEMENT set RE_START_DATE = TO_DATE(SYSDATE,'YYYY-MM-DD') where sd_num = ? and LOA_A_DATE = ?");
				pstmt.setInt(1, id);
				pstmt.setString(2, LOA_A_DATE);
				int count = pstmt.executeUpdate();
				return count;

			}catch(SQLException e){
				throw new RuntimeException("DB 에러:"+e.getMessage(), e);
			}
			finally{
				jdbcUtil.close(pstmt);
			}
		}
		
		////////////********휴복학 select 문 써야됨
		public ReinstatementDataBean  selectReinstatement(Connection conn,int id){
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try{
				pstmt = conn.prepareStatement("select SD_NUM,RE_LOA_DATE,LOA_END_YEAR,LOA_END_SEMESTER,LOA_A_DATE,RE_START_DATE,RE_END_DATE from (select * from REINSTATEMENT where sd_num = ? order by RE_LOA_DATE desc) where ROWNUM <= 1;");
				pstmt.setInt(1, id);
				rs = pstmt.executeQuery();
				ReinstatementDataBean item = makeItemReinstatementResultSet(rs);
				return item;

			}catch(SQLException e){
				throw new RuntimeException("DB 에러:"+e.getMessage(), e);
			}
			finally{
				jdbcUtil.close(pstmt);
			}
		}
}

