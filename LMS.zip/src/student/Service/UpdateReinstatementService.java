package student.Service;

import java.sql.Connection;
import java.sql.SQLException;

import jdbc.ConnectionProvider;
import jdbc.jdbcUtil;
import student.DAO.StudentDao;

public class UpdateReinstatementService {
	private static UpdateReinstatementService instance = new UpdateReinstatementService();
	
	public static UpdateReinstatementService getInstance(){
		return instance;
	}
	private UpdateReinstatementService(){}
	public int setItem(int id,String LOA_A_DATE){

		StudentDao studentDao = StudentDao.getInstance();
		Connection conn = null;
		try{
			conn = ConnectionProvider.getConnection();
			int check = studentDao.updateReinstatementLOA(conn, id, LOA_A_DATE);
			return check;
		}catch(SQLException e){
			throw new RuntimeException("DB 에러:"+e.getMessage(), e);
		}finally{
			jdbcUtil.close(conn);
		}
	}
}
