function test(ul){
	var id = document.getElementbyid("test");
	for(var i=0; i<id.size;i++){
		if(id.li[i]==="active"){
			
		}
	}
}